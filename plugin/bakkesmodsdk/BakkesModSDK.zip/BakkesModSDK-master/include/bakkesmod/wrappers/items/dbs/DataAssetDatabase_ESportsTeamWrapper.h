#pragma once
#include "DataAssetDatabaseWrapper.h"


class BAKKESMOD_PLUGIN_IMPORT DataAssetDatabase_ESportsTeamWrapper : public DataAssetDatabaseWrapper {
public:
	CONSTRUCTORS(DataAssetDatabase_ESportsTeamWrapper)

	//BEGIN SELF IMPLEMENTED
	//END SELF IMPLEMENTED

	//AUTO-GENERATED FROM FIELDS
	//END AUTO-GENERATED FROM FIELDS

	//AUTO-GENERATED FROM METHODS
	//END AUTO-GENERATED FROM METHODS

private:
	PIMPL
};